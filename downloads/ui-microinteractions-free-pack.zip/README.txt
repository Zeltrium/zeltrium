UI Micro-Interactions — Free Mini-Pack
by Zeltrium (zeltrium.com)

------------------------------------------------------------
WHAT'S INSIDE
------------------------------------------------------------
5 hand-crafted Lottie animations, each provided in two formats:

  json/
    success.json
    notification.json
    like.json
    toggle.json
    bookmark.json

  dotlottie/
    success.lottie
    notification.lottie
    like.lottie
    toggle.lottie
    bookmark.lottie

Use whichever format fits your stack — .json is the raw Lottie format
(works with lottie-web, lottie-player, react-lottie, Lottie for
Android/iOS, After Effects re-import, etc.), .lottie (dotLottie) is the
newer compressed container format (works with the dotlottie-web /
dotlottie-player runtimes, and is the smaller file to ship).

------------------------------------------------------------
HOW TO USE
------------------------------------------------------------
Web (Lottie Player) — grab the player library from npm/a CDN of your
choice (e.g. @lottiefiles/lottie-player), then:
  <lottie-player src="success.json" background="transparent"
    speed="1" style="width:64px;height:64px;" autoplay>
  </lottie-player>

Web (dotLottie Player) — grab @lottiefiles/dotlottie-web (or the player
of your choice), then:
  <dotlottie-player src="success.lottie" background="transparent"
    speed="1" style="width:64px;height:64px;" autoplay>
  </dotlottie-player>

React / iOS / Android / After Effects:
  Import the .json file with your framework's Lottie library of choice
  (lottie-react, lottie-ios, lottie-android, or drag the .json straight
  into After Effects via the Lottie import plugin).

------------------------------------------------------------
LICENSE
------------------------------------------------------------
See LICENSE.txt — free for personal and commercial use, no attribution
required.

------------------------------------------------------------
WANT ALL 30?
------------------------------------------------------------
This is a 5-animation preview of the full 30-animation set.
Get the complete pack: https://zeltrium.gumroad.com/l/lottie-ui-micro-interactions

Questions? zeltriumstudio@gmail.com
