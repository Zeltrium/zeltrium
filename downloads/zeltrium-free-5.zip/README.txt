Zeltrium — Free 5 Micro-Interactions
zeltrium.com

Thanks for grabbing the sampler. Here are 5 Lottie animations for the
moments you hit every week: success, error, copy, checkbox and refresh.

------------------------------------------------------------
WHAT'S INSIDE
------------------------------------------------------------
  json/        success.json  error.json  copy.json  checkbox.json  refresh.json
  dotlottie/   the same 5 as .lottie (compressed, smaller to ship)

  30 fps, 400 x 400 canvas (error is 500 x 400: room for its shake).
  Each file is 2.6–9.7 KB as .json.

Use .json with any Lottie player. Use .lottie with dotLottie players.

------------------------------------------------------------
DROP IT IN
------------------------------------------------------------
React (lottie-react)
  import Lottie from "lottie-react";
  import success from "./zeltrium/success.json";
  <Lottie animationData={success} loop={false} />

iOS (lottie-ios)
  let view = LottieAnimationView(name: "success")
  view.play()

Android (lottie-android)
  <com.airbnb.lottie.LottieAnimationView
      app:lottie_rawRes="@raw/success"
      app:lottie_autoPlay="false" />

Flutter (lottie)
  Lottie.asset('assets/zeltrium/success.json', repeat: false)

Framer:  Insert → Lottie → drop success.lottie → Playback: On Click
Webflow: Add → Lottie Animation → upload success.json → trigger on click

Tip: checkbox plays forward to check and backward to uncheck.
Play it in reverse instead of restarting it.

------------------------------------------------------------
RECOLOR
------------------------------------------------------------
Colors are flat fills and strokes. Change them in a Lottie editor, in
After Effects, or in code by replacing one RGB value per color.

------------------------------------------------------------
LICENSE
------------------------------------------------------------
Free for personal and commercial projects, client work included.
No attribution required. Don't resell or redistribute the files
themselves. Full terms in LICENSE.txt.

------------------------------------------------------------
WANT ALL 30?
------------------------------------------------------------
Likes, toggles, menus, uploads, deletes, notifications and more,
in the same style: https://zeltrium.gumroad.com/l/lottie-ui-micro-interactions

Questions: zeltriumstudio@gmail.com
